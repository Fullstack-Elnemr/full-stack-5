<?php
require_once 'config/constants.php';
require_once ADMIN_CONFIG_PATH . 'config.php';
//require_once 'libs/user.lib.php';
print_r(getAllUsers());
